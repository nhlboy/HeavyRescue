create
    definer = bb3444f3a67bf0@`%` procedure first_n_adresses(IN val int)
BEGIN
        SELECT * FROM adress LIMIT val;
    END;

