create
    definer = bb3444f3a67bf0@`%` procedure price_more_than(IN price int)
BEGIN
    SELECT * FROM products WHERE Price > price;
end;

