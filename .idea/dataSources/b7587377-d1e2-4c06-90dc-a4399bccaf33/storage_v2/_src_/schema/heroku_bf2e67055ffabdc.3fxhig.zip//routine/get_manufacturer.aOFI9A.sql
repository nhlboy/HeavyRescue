create
    definer = bb3444f3a67bf0@`%` procedure get_manufacturer(IN product_name varchar(10), OUT manufacturer varchar(10))
BEGIN
    DECLARE manufacturer_list VARCHAR(10);
    SELECT Manufacturer INTO manufacturer_list FROM products
        WHERE ProductName = product_name;
    IF product_name = ANY (SELECT ProductName FROM products WHERE ProductName REGEXP 'Phone')
        THEN SET manufacturer = 'Apple';
    ELSEIF product_name = ANY (SELECT ProductName FROM products WHERE ProductName REGEXP 'Galaxy')
    THEN SET manufacturer = 'Samsung';
    ELSEIF product_name = ANY (SELECT ProductName FROM products WHERE ProductName REGEXP 'Honor')
    THEN SET manufacturer = 'Huawei';
    END IF;
    END;

