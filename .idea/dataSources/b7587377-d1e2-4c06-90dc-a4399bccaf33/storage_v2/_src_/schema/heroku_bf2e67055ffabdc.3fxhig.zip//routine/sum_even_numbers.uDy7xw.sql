create
    definer = bb3444f3a67bf0@`%` procedure sum_even_numbers(OUT result int, IN n int)
BEGIN
    SET @sum = 0;
    SET @x = 1;
    REPEAT
        IF mod(@x, 2) = 0
        THEN SET @sum = @sum + @x;
        END IF;
        SET @x = @x + 1;
        UNTIL @x > n
    END REPEAT;
    SET result = @sum;
    END;

