create
    definer = bb3444f3a67bf0@`%` procedure number_of_rows(IN val int)
BEGIN
    SELECT * FROM products LIMIT val;
end;

