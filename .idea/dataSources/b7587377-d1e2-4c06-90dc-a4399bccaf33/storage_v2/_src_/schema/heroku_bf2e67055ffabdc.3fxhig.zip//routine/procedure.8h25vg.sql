create
    definer = bb3444f3a67bf0@`%` procedure `procedure`()
BEGIN
    SELECT COUNT(*) FROM products;
END;

