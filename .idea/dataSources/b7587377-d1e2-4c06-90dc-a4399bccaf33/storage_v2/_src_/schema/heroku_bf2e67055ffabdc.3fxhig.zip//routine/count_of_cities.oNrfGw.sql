create
    definer = bb3444f3a67bf0@`%` procedure count_of_cities(OUT count int)
BEGIN
    SELECT COUNT(DISTINCT city) INTO count FROM adress;
END;

