create
    definer = bb3444f3a67bf0@`%` procedure max_price(OUT max_price int)
BEGIN
    SELECT MAX(Price) INTO max_price FROM products;
end;

