create
    definer = bb3444f3a67bf0@`%` procedure more_items_than(IN items int)
BEGIN
    SELECT * FROM products WHERE ProductCount > items;
end;

