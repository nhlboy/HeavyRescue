create
    definer = bb3444f3a67bf0@`%` procedure distinct_countries(OUT count int)
BEGIN
        SELECT COUNT(DISTINCT country) INTO count FROM adress;
    END;

